import React, { useCallback, useState } from "react";

import { IntlProvider } from "react-intl";

import ExampleComponent from "./components/ExampleComponent";
import LanguageSetting from "./components/LanguageSetting";

import { languageParser } from "./utils/language";

import "./styles.css";

require("@formatjs/intl-relativetimeformat/locale-data/ko");
require("@formatjs/intl-relativetimeformat/locale-data/en");
require("@formatjs/intl-relativetimeformat/locale-data/ja");
require("@formatjs/intl-pluralrules/locale-data/ko");
require("@formatjs/intl-pluralrules/locale-data/en");
require("@formatjs/intl-pluralrules/locale-data/ja");

const USAGE_LANG = ["ko", "en", "ja"];
function App() {
  const [locale, setLocale] = useState(languageParser(navigator.language).lang);

  const changeLocale = useCallback((lang) => {
    setLocale(lang);
  }, []);

  return (
    <IntlProvider defaultLocale="ko" locale={locale}>
      <LanguageSetting
        setLang={changeLocale}
        locale={locale}
        usageLang={USAGE_LANG}
      />
      <ExampleComponent exampleService="devth.goorm.io" />
    </IntlProvider>
  );
}

export default App;
