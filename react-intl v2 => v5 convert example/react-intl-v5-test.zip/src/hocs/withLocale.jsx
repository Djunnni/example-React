import React from "react";
import { IntlProvider, injectIntl, useIntl } from "react-intl";

const withLocale = (messages) => (Component) =>
  injectIntl((props) => {
    const { locale } = useIntl();
    return (
      <IntlProvider
        locale={locale}
        messages={Object.assign({}, messages[locale])}
      >
        <Component {...props} />
      </IntlProvider>
    );
  });

export default withLocale;
