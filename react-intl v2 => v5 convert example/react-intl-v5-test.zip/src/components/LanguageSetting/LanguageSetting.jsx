function LanguageSetting({ locale, setLang, usageLang }) {
  return (
    <div>
      <div>current lang: {locale}</div>
      <sub>click locale!</sub>
      <ul>
        {usageLang.map((lang) => {
          return (
            <li key={lang} onClick={() => setLang(lang)}>
              {lang}
            </li>
          );
        })}
      </ul>
      <hr />
    </div>
  );
}
export default LanguageSetting;
