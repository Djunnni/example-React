import LanguageSetting from "./LanguageSetting";
export default LanguageSetting;
