import React from "react";

import {
  FormattedNumber,
  FormattedDate,
  FormattedDateParts,
  FormattedMessage,
  FormattedDateTimeRange,
  injectIntl,
  useIntl
} from "react-intl";

import withLocale from "../../hocs/withLocale";
import messages from "./locale.json";

function ExampleComponent({ exampleService }) {
  const intl = useIntl();
  console.log(intl);
  const onClick = () => {
    console.log(
      intl.formatMessage({
        defaultMessage: "버튼을 클릭했어요.",
        id: "Common.button.click"
      })
    );
  };
  return (
    <div className="example">
      <div>
        App Component props exampleService: <i id="devth">{exampleService}</i>
      </div>
      <div>
        props intl onClick Event Example:{" "}
        <FormattedMessage id="Common.button" defaultMessage="버튼">
          {(text) => <button onClick={onClick}>{text}</button>}
        </FormattedMessage>
      </div>
      <div>
        <p>
          FormattedMessage Example:{" "}
          <FormattedMessage id="Common.name" defaultMessage="이름" />
        </p>
      </div>
      <div>
        Rich FormattedMessage Example:{" "}
        <FormattedMessage
          id="Rich.FormattedMessage.Example"
          defaultMessage="To more using, <a>visit our website</a> and <cta>contact us</cta>"
          values={{
            a: (chunks) => (
              <a target="_blank" href="https://devth.goorm.io/">
                {chunks}
              </a>
            ),
            cta: (chunks) => <strong>{chunks}</strong>
          }}
        />
      </div>
      <div>
        <p>
          FormattedNumber currency Example:{" "}
          <FormattedNumber value={22000} style="currency" currency="KRW" />
        </p>
        <p>
          FormattedNumber Kilo Example:{" "}
          <FormattedNumber
            value={1000}
            style="unit"
            unit="kilobyte"
            unitDisplay="narrow"
          />
        </p>
      </div>
      <div>
        FormattedDate Example:{" "}
        <FormattedDate
          value={new Date()}
          year="numeric"
          month="long"
          day="2-digit"
        />
      </div>
      <div>
        FormattedDateParts Example:{" "}
        <FormattedDateParts
          value={new Date()}
          year="numeric"
          month="long"
          day="2-digit"
        >
          {(parts) => (
            <>
              <b>{parts[0].value}</b>
              {parts[1].value}
              <small>{parts[2].value}</small>
            </>
          )}
        </FormattedDateParts>
      </div>
      <div>
        FormattedDateTimeRange Example:{" "}
        <FormattedDateTimeRange
          from={new Date("2022-2-1")}
          to={new Date("2022-2-6")}
        />
      </div>
    </div>
  );
}

export default withLocale(messages)(injectIntl(ExampleComponent));
