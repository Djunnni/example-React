import ExampleComponent from "./ExampleComponent";
export default ExampleComponent;
