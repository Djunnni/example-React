/*
 * function languageParser
 * (navigator.language) => { lang, country }
 *
 * description
 * en의 경우, en-US, en-GK 같은 경우가 발생해, navigator로 받을 경우 parsing이 필요.
 *
 * example
 * en-US => { lang: en, country: US }
 */

export function languageParser(language) {
  const [lang, country] = language.split("-");
  return { lang, country };
}
