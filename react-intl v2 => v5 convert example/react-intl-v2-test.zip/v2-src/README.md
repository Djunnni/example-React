Current Locale Environment

"react-intl": "2.7.2",
"babel-plugin-react-intl": "2.4.0",
