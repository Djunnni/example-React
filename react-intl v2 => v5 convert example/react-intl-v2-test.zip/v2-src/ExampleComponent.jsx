import React from "react";

import { FormattedMessage, injectIntl } from "react-intl";
function ExampleComponent() {
  return (
    <div>
      <FormattedMessage id="Common.name" defaultMessage="이름" />
    </div>
  );
}

export default injectIntl(ExampleComponent);
