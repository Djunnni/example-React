import React from "react";

import { FormattedMessage, injectIntl } from "react-intl";

import withLocale from "../../hocs/withLocale";
import messages from "./locale.json";

function ExampleComponent({}) {
  return (
    <div>
      <FormattedMessage id="Common.name" defaultMessage="이름" />
    </div>
  );
}

export default withLocale(messages)(ExampleComponent);
