import React, { useCallback, useState } from "react";

import { addLocaleData, IntlProvider } from "react-intl";

import koLocaleData from "react-intl/locale-data/ko";
import jaLocaleData from "react-intl/locale-data/ja";

import ExampleComponent from "./components/ExampleComponent";

import "./styles.css";

addLocaleData(koLocaleData);
addLocaleData(jaLocaleData);

function LanguageSetting({ locale, setLang }) {
  return (
    <>
      <div>current lang: {locale}</div>
      <ul>
        <li onClick={() => setLang("ko")}>ko</li>
        <li onClick={() => setLang("en")}>en</li>
        <li onClick={() => setLang("ja")}>ja</li>
      </ul>
    </>
  );
}
function App() {
  const [locale, setLocale] = useState("ko");

  const changeLocale = useCallback((lang) => {
    setLocale(lang);
  }, []);
  return (
    <IntlProvider locale={locale}>
      <>
        <LanguageSetting setLang={changeLocale} locale={locale} />
        <ExampleComponent />
      </>
    </IntlProvider>
  );
}

export default App;
