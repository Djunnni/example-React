import React from "react";
import { IntlProvider, injectIntl } from "react-intl";

const withLocale = (messages) => (Component) =>
  injectIntl(
    class extends React.PureComponent {
      render() {
        const { locale } = this.props.intl;
        return (
          <IntlProvider messages={Object.assign({}, messages[locale])}>
            <Component {...this.props} />
          </IntlProvider>
        );
      }
    }
  );

export default withLocale;
