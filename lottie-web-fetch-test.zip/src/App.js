import React, { useRef, useEffect, useState, useLayoutEffect } from "react";
import "./styles.css";

import lottie from "lottie-web";

const ANIME = [
  "https://statics.goorm.io/obserview/lottie/1.json",
  "https://statics.goorm.io/obserview/lottie/2.json"
];

function Lottie({ screen, source }) {
  const ref = useRef();
  const screenSource = useRef();

  useEffect(() => {
    const fetchData = async (url) => {
      const ret = await fetch(url);
      return ret.json();
    };
    if (source) {
      Promise.all(source.map((x) => fetchData(x))).then((arr) => {
        screenSource.current = arr;
      });
    }
  }, [source]);

  useEffect(() => {
    if (ref?.current && screenSource?.current?.[screen]) {
      lottie.loadAnimation({
        animationData: screenSource.current[screen],
        container: ref.current,
        renderer: "svg",
        loop: true,
        autoplay: true
      });
      return () => lottie.destroy();
    }
  }, [ref, screen, screenSource]);

  return <div ref={ref}></div>;
}

function App() {
  const [number, setNumber] = useState(0);

  const nextButton = () => {
    setNumber((prev) => (prev + 1) % ANIME.length);
  };

  return (
    <div className="App">
      <h1>Lottie Example</h1>
      <div className="Container">
        <Lottie source={ANIME} screen={number} />
        <div>
          <h2>lottie animation</h2>
          <p>current : {number + 1}</p>
          <button onClick={nextButton}>next</button>
        </div>
      </div>
    </div>
  );
}

export default App;
